var params = {
	flag : false,
	stop : true,
	once : 1000,
	rhyt : 4,
	count: 4
};
var rhythms = ['2/4','3/4','4/4'];